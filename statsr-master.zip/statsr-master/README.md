
<!-- README.md is generated from README.Rmd. Please edit that file -->
[![Build Status](https://travis-ci.org/StatsWithR/statsr.svg?branch=master)](https://travis-ci.org/StatsWithR/statsr)

statsr
======

Companion package for the Coursera *Statistics with R* specialization

To install the latest version from github, verify that there is passing badge above on the README page. In `R` enter

``` r
library(devtools)
devtools::install_github("statswithr/statsr")
```
