# News for statsr

# statsr 0.0.1

* First release of package on CRAN