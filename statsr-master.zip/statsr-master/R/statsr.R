#' statsr: A companion package for the Coursera Statistics with R specialization
#'
#' See https://github.com/StatsWithR/statsr for more information.
#'
#' @docType package
#' @name statsr
#' @import stats
#' @import graphics
#' @import ggplot2
#' @import shiny
NULL